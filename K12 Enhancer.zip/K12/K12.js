var icons = document.head.querySelectorAll("link[rel*='icon']");
for(var i = 0; i < icons.length; i++){
    icons[i].href = "https://techpro-services.github.io/Images/K12%20Enhancer.png";
}