chrome.runtime.onInstalled.addListener(function(e){
    console.log("HELLO!");
    /*
    chrome.declarativeNetRequest.updateEnabledRulesets({disableRulesetIds: ["newrow_ruleset"]});
    chrome.declarativeNetRequest.getEnabledRulesets((details) => {
        console.log(details);
    })
    chrome.declarativeNetRequest.updateEnabledRulesets({enableRulesetIds: ["newrow_ruleset"]});*/
    }
)